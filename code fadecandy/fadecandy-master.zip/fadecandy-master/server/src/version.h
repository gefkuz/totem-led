#pragma once
extern const char *kFCServerVersion;
