Rapidjson 0.11
--------------

This directory contains third party sources from the
[rapidjson project](https://code.google.com/p/rapidjson/). MIT Licensed.
